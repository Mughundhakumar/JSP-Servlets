package com.jdbc.user.demo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import com.jdbc.user.demo.model.User;

public class UserDAO {
	
	private DataSource dataSource;
	
	public UserDAO(DataSource theDataSource) {
		dataSource = theDataSource;
	}
	
	public List<User> getUsers() throws Exception{
		List<User> users = new ArrayList<>();
		
		Connection con = null;
		Statement statement = null;
		ResultSet resultSet = null;
		
		try {
			con = dataSource.getConnection();
			String query = "select * from users";
			
			statement = con.createStatement();
			resultSet = statement.executeQuery(query);
			
			while(resultSet.next()) {
				int userId = resultSet.getInt("user_id");
				String firstName = resultSet.getString("firstname");
				String lastName = resultSet.getString("lastname");
				String email = resultSet.getString("email");
				
				User usr = new User(userId,firstName,lastName,email);
				
				users.add(usr);
			}
			
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			close(con,statement,resultSet);
		}
		return users;
		
	}

	private void close(Connection con, Statement statement, ResultSet resultSet) {
		
		try {
			if(resultSet != null) {
				resultSet.close();
			}
			
			if(statement != null) {
				statement.close();
			}
			
			if(con != null) {
				con.close();
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public void addUser(User user) throws Exception {

		Connection myConn = null;
		PreparedStatement myStmt = null;
		
		try {
			// get db connection
			myConn = dataSource.getConnection();
			
			// create sql for insert
			String sql = "insert into users "
					   + "(firstname, lastname, email) "
					   + "values (?, ?, ?)";
			
			myStmt = myConn.prepareStatement(sql);
			
			// set the param values for the student
			myStmt.setString(1, user.getFirstName());
			myStmt.setString(2, user.getLastName());
			myStmt.setString(3, user.getEmail());
			
			// execute sql insert
			myStmt.execute();
		}
		finally {
			// clean up JDBC objects
			close(myConn, myStmt, null);
		}
	}

	public User getUser(String userId) throws Exception{
		User user = null;
		Connection con = null;
		PreparedStatement psStatement = null;
		ResultSet rs = null;
		int theUserId;
		try {
			theUserId = Integer.parseInt(userId);
			
			con = dataSource.getConnection();
			
			String query = "select * from users where user_id= ?";
			
			psStatement = con.prepareStatement(query);
			psStatement.setInt(1, theUserId);
			
			rs = psStatement.executeQuery();
			
			if(rs.next()) {
				String firstName = rs.getString("firstname");
				String lastName = rs.getString("lastname");
				String email = rs.getString("email");
				
				user = new User(theUserId,firstName,lastName,email);
			} else {
				throw new Exception("Could not find the user id: "+theUserId);
			}
			
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			close(con,psStatement,rs);
		}
		return user;
	}

	public void updateUser(User theUser) throws Exception{
		
		Connection con = null;
		PreparedStatement psStatement = null;
		
		try {
			con = dataSource.getConnection();
			String query = "update users set firstname=?, lastname=?, email=? where user_id= ?";
			psStatement = con.prepareStatement(query);
			psStatement.setString(1, theUser.getFirstName());
			psStatement.setString(2, theUser.getLastName());
			psStatement.setString(3, theUser.getEmail());
			psStatement.setInt(4, theUser.getUserId());
			
			psStatement.execute();
		}catch(Exception e) {
			e.printStackTrace();
		} finally {
			close(con,psStatement,null);
		}
	}

	public void deleteUser(int userId) {
		Connection con = null;
		PreparedStatement psStatement = null;
		
		try {
			con = dataSource.getConnection();
			String query = "delete from users where user_id= ?";
			psStatement = con.prepareStatement(query);
			psStatement.setInt(1, userId);
			
			psStatement.execute();
		}catch(Exception e) {
			e.printStackTrace();
		} finally {
			close(con,psStatement,null);
		}
		
	}

}
