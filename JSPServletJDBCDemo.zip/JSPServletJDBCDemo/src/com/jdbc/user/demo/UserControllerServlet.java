package com.jdbc.user.demo;

import java.io.IOException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.jdbc.user.demo.dao.UserDAO;
import com.jdbc.user.demo.model.User;

/**
 * Servlet implementation class UserControllerServlet
 */
@WebServlet("/UserControllerServlet")
public class UserControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private UserDAO userDao;

	@Resource(name = "userTracker")
	private DataSource dataSource;

	@Override
	public void init() throws ServletException {
		super.init();

		try {
			userDao = new UserDAO(dataSource);
		} catch (Exception e) {
			throw new ServletException(e);
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		try {
			// read the "command" parameter
			String theCommand = request.getParameter("command");

			// if the command is missing, then default to listing students
			if (theCommand == null) {
				theCommand = "LIST";
			}

			// route to the appropriate method
			switch (theCommand) {

			case "LIST":
				listUsers(request, response);
				break;

			case "ADD":
				addUser(request, response);
				break;

			case "LOAD":
				loadUser(request, response);
				break;

			case "UPDATE":
				updateUser(request, response);
				break;
			
			case "DELETE":
				deleteUser(request, response);
				break;

			default:
				listUsers(request, response);
			}
		} catch (Exception e) {
			throw new ServletException(e);
		}
	}

	private void deleteUser(HttpServletRequest request, HttpServletResponse response) throws Exception{
		
		int userId = Integer.parseInt(request.getParameter("userId"));
		
		userDao.deleteUser(userId);
		
		listUsers(request, response);
		
	}

	private void updateUser(HttpServletRequest request, HttpServletResponse response) throws Exception{

		int userId = Integer.parseInt(request.getParameter("userId"));
		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		String email = request.getParameter("email");
		
		User theUser = new User(userId,firstName,lastName,email);
		
		userDao.updateUser(theUser);
		
		listUsers(request, response);

	}

	private void loadUser(HttpServletRequest request, HttpServletResponse response) throws Exception {

		String userId = request.getParameter("userId");

		User user = userDao.getUser(userId);

		request.setAttribute("THE_USER", user);

		RequestDispatcher dispatcher = request.getRequestDispatcher("/update-user-form.jsp");
		dispatcher.forward(request, response);
	}

	private void addUser(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// read student info from form data
		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		String email = request.getParameter("email");

		// create a new student object
		User theUser = new User(firstName, lastName, email);

		// add the student to the database
		userDao.addUser(theUser);

		// send back to main page (the student list)
		listUsers(request, response);

	}

	private void listUsers(HttpServletRequest request, HttpServletResponse response) throws Exception {

		List<User> users = userDao.getUsers();

		request.setAttribute("USER_LIST", users);

		RequestDispatcher dispatcher = request.getRequestDispatcher("/list-users.jsp");
		dispatcher.forward(request, response);
	}

}
